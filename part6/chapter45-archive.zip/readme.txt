Theme Name: 자료창고
Theme URI:
Maker: 한종배
Maker URI:
Version: 1.0.0
Detail: 커뮤니티 테마는  책에 사용하기 위해 만든 그누보드5 테마입니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html