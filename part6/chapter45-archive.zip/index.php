<?php
if (!defined('_INDEX_')) define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/index.php');
    return;
}

if(G5_COMMUNITY_USE === false) {
    include_once(G5_THEME_SHOP_PATH.'/index.php');
    return;
}

include_once(G5_THEME_PATH.'/head.php');
?>

<div class="hero">
    <div class="hero_inner">
        <span class="hero_eyebrow">STUDY ARCHIVE</span>
        <h2>모아두면 자산이 되는<br>스터디 자료창고</h2>
        <p>등급에 맞는 자료를 찾아 열람하고, 필요한 자료는 직접 등록해 포인트로 보상받으세요.</p>
        <div class="hero_actions">
            <a href="<?php echo G5_BBS_URL; ?>/board.php?bo_table=archive_free" class="btn_hero btn_hero_primary">일반자료실 바로가기</a>
            <a href="<?php echo G5_BBS_URL; ?>/board.php?bo_table=archive_pro" class="btn_hero btn_hero_ghost">프리미엄자료실 바로가기</a>
        </div>
    </div>
</div>

<div class="tier_cards">
    <div class="tier_card">
        <span class="tier_badge tier_badge_free">LV.2+</span>
        <h3>일반자료실</h3>
        <p>가입만 하면 누구나 열람·다운로드·자료 등록이 가능합니다.</p>
        <a href="<?php echo G5_BBS_URL; ?>/board.php?bo_table=archive_free">자료 보러가기 →</a>
    </div>
    <div class="tier_card tier_card_pro">
        <span class="tier_badge tier_badge_pro">LV.3+</span>
        <h3>프리미엄자료실</h3>
        <p>정회원 등급부터 열람 가능하며, 다운로드 시 포인트가 차감됩니다.</p>
        <a href="<?php echo G5_BBS_URL; ?>/board.php?bo_table=archive_pro">자료 보러가기 →</a>
    </div>
</div>

<div class="archive_latest">
    <?php
    echo latest('theme/basic', 'archive_free', 5, 30);
    echo latest('theme/basic', 'archive_pro', 5, 30);
    ?>
</div>

<?php
include_once(G5_THEME_PATH.'/tail.php');