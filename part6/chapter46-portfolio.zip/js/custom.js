document.addEventListener('DOMContentLoaded', function () {
    var grid = document.querySelector('#work_grid');
    if (!grid) return;

    // 이미지 로딩이 끝난 뒤에 레이아웃을 잡아야 썸네일이 겹쳐 보이는 문제가 없다
    imagesLoaded(grid, function () {
        var iso = new Isotope(grid, {
            itemSelector: '.work_item',
            layoutMode: 'fitRows'
        });

        var filterButtons = document.querySelectorAll('.filter_btn');
        filterButtons.forEach(function (btn) {
            btn.addEventListener('click', function () {
                filterButtons.forEach(function (b) { b.classList.remove('active'); });
                btn.classList.add('active');
                iso.arrange({ filter: btn.dataset.filter });
            });
        });
    });
});