<?php
if (!defined('_INDEX_')) define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit;

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/index.php');
    return;
}

if(G5_COMMUNITY_USE === false) {
    include_once(G5_THEME_SHOP_PATH.'/index.php');
    return;
}

include_once(G5_THEME_PATH.'/head.php');
?>

<section id="hero">
    <h1>안녕하세요,<br>웹 퍼블리셔 <span class="accent">김도윤</span>입니다</h1>
    <p>그누보드5 기반 사이트를 반응형으로 설계하고 구현합니다.</p>
    <div class="hero_btns">
        <a href="#works" class="btn btn_primary">작업물 보기</a>
        <a href="<?php echo G5_DATA_URL ?>/file/resume.pdf" class="btn btn_outline">이력서 다운로드</a>
    </div>
</section>

<section id="about">
    <h2>About Me</h2>
    <p>그누보드5 기반 사이트를 반응형으로 설계·구현하는 웹 퍼블리셔입니다. ...(소개 문구)</p>
</section>

<section id="works">
    <h2>Works</h2>

    <?php
    $board_works = sql_fetch(" select * from {$g5['board_table']} where bo_table = 'works' ");
    $category_list = array_filter(explode('|', $board_works['bo_category_list']));
    ?>

    <div class="filter_bar">
        <button type="button" class="filter_btn active" data-filter="*">전체</button>
        <?php foreach ($category_list as $ca) { ?>
        <button type="button" class="filter_btn" data-filter=".<?php echo $ca ?>"><?php echo $ca ?></button>
        <?php } ?>
    </div>

    <div class="work_grid" id="work_grid">
        <?php
        $write_table = $g5['write_prefix'].'works';
        $sql = " select * from {$write_table} where wr_is_comment = 0 order by wr_num asc ";
        $result = sql_query($sql);
        for ($i = 0; $row = sql_fetch_array($result); $i++) {
            // 대표 이미지 1장 (Step 1-2에서 파일 업로드 개수를 1로 제한해 두었으므로 bf_no는 항상 0)
            $file = sql_fetch(" select bf_file from {$g5['board_file_table']}
                                 where bo_table = 'works' and wr_id = '{$row['wr_id']}' and bf_no = 0 ");
            if (!$file['bf_file']) continue; // 대표 이미지가 없는 글은 건너뛴다

            $img_src = G5_DATA_URL.'/file/works/'.$file['bf_file'];
        ?>
        <div class="work_item <?php echo $row['ca_name'] ?>">
            <a href="<?php echo $img_src ?>" data-lightbox="works" data-title="<?php echo get_text($row['wr_subject']) ?>">
                <img src="<?php echo $img_src ?>" alt="<?php echo get_text($row['wr_subject']) ?>" loading="lazy">
                <div class="work_caption">
                    <strong><?php echo get_text($row['wr_subject']) ?></strong>
                    <span><?php echo $row['wr_1'] ?></span>
                </div>
            </a>
        </div>
        <?php } ?>
    </div>
</section>

<section id="skills">
    <h2>Skills</h2>
    <ul class="skill_list">
        <li>HTML5 / CSS3</li>
        <li>JavaScript (ES6+)</li>
        <li>PHP</li>
        <li>그누보드5 커스터마이징</li>
    </ul>
</section>

<section id="contact">
    <h2>Contact</h2>
    <p>포트폴리오에 대해 궁금한 점이나 협업 제안은 아래 버튼으로 편하게 문의해 주세요.</p>
    <a class="btn btn_primary" href="<?php echo G5_BBS_URL ?>/write.php?bo_table=contact" target="_blank" rel="noopener">문의 글쓰기</a>
</section>

<?php
include_once(G5_THEME_PATH.'/tail.php');