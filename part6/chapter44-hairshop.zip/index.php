<?php
if (!defined('_INDEX_')) define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/index.php');
    return;
}

if(G5_COMMUNITY_USE === false) {
    include_once(G5_THEME_SHOP_PATH.'/index.php');
    return;
}

include_once(G5_THEME_PATH.'/head.php');

$dow_kr = array('일','월','화','수','목','금','토');
?>

<div class="hero">
    <div class="hero_inner">
        <div class="hero_copy">
            <span class="hero_eyebrow">OO헤어 예약</span>
            <h2>손끝에서 완성되는<br>편안한 시간</h2>
            <p>컷·펌·염색·클리닉까지, 원하시는 날짜와 시간을 남겨주시면<br>확인 후 빠르게 연락드립니다.</p>
            <a href="<?php echo G5_BBS_URL; ?>/write.php?bo_table=reserve" class="hero_cta">지금 예약하기</a>
        </div>
        <div class="hero_days">
            <?php
            for ($i = 0; $i < 7; $i++) {
                $ts = strtotime("+{$i} day");
                $is_today = ($i == 0) ? ' today' : '';
            ?>
            <a class="hero_day<?php echo $is_today; ?>"
               href="<?php echo G5_BBS_URL; ?>/write.php?bo_table=reserve&amp;wr_1=<?php echo date('Y-m-d', $ts); ?>">
                <span class="dow"><?php echo $dow_kr[date('w', $ts)]; ?></span>
                <span class="dom"><?php echo date('j', $ts); ?>일</span>
            </a>
            <?php } ?>
        </div>
    </div>
</div>

<div class="quicklinks">
    <a href="<?php echo get_pretty_url('content', 'reserve_info'); ?>">
        <i class="fa fa-info-circle ql_icon" aria-hidden="true"></i>
        <h3>예약 안내</h3>
        <p>운영 시간과 예약 방법을 확인하세요.</p>
    </a>
    <a href="<?php echo G5_BBS_URL; ?>/board.php?bo_table=reserve">
        <i class="fa fa-calendar ql_icon" aria-hidden="true"></i>
        <h3>예약 신청</h3>
        <p>원하는 날짜와 시술을 남겨주세요.</p>
    </a>
    <a href="<?php echo get_pretty_url('content', 'location'); ?>">
        <i class="fa fa-map-marker ql_icon" aria-hidden="true"></i>
        <h3>오시는 길</h3>
        <p>매장 위치와 주차 안내입니다.</p>
    </a>
</div>

<div class="services">
    <h2>시술 안내</h2>
    <ul class="services_grid">
        <li><span class="sv_name">컷</span><span class="sv_desc">얼굴형과 라이프스타일에 맞춘 커트</span></li>
        <li><span class="sv_name">펌</span><span class="sv_desc">자연스러운 볼륨과 웨이브</span></li>
        <li><span class="sv_name">염색</span><span class="sv_desc">두피 손상을 최소화한 컬러링</span></li>
        <li><span class="sv_name">클리닉</span><span class="sv_desc">손상 모발을 위한 집중 케어</span></li>
    </ul>
</div>

<?php
include_once(G5_THEME_PATH.'/tail.php');