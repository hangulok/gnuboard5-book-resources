<?php
if (!defined('_INDEX_')) define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/index.php');
    return;
}

if(G5_COMMUNITY_USE === false) {
    include_once(G5_THEME_SHOP_PATH.'/index.php');
    return;
}
// Swiper.js 슬라이더 라이브러리 등록
add_stylesheet('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@14/swiper-bundle.min.css">', 0);
add_javascript('<script src="https://cdn.jsdelivr.net/npm/swiper@14/swiper-bundle.min.js"></script>', 0);


include_once(G5_THEME_PATH.'/head.php');
?>
<!-- theme/basic/index.php 슬라이더 영역 -->
<div class="swiper cafe-slider">
    <div class="swiper-wrapper">
        <div class="swiper-slide">
            <img src="<?php echo G5_THEME_IMG_URL; ?>/main_slide1.svg" alt="오후의 커피 매장 전경">
        </div>
        <div class="swiper-slide">
            <img src="<?php echo G5_THEME_IMG_URL; ?>/main_slide2.svg" alt="시그니처 라떼">
        </div>
        <div class="swiper-slide">
            <img src="<?php echo G5_THEME_IMG_URL; ?>/main_slide3.svg" alt="매장 좌석">
        </div>
    </div>
    <div class="swiper-pagination"></div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
</div>

<!-- theme/basic/index.php 공지사항 영역 -->
<section class="main-notice">
    <?php echo latest('basic', 'notice', 5, 30); ?>
</section>

<section class="main-event">
    <?php echo latest('basic', 'event', 3, 30); ?>
</section>
<script>
new Swiper('.cafe-slider', {
    loop: true,
    autoplay: {
        delay: 3000,
    },
    pagination: {
        el: '.swiper-pagination',
    },
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
});
</script>
<?php
include_once(G5_THEME_PATH.'/tail.php');